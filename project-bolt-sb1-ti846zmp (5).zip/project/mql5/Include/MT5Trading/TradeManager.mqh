//+------------------------------------------------------------------+
//|                                             TradeManager.mqh       |
//|                                    MT5 Trading System             |
//|                                    مدیریت معاملات                 |
//+------------------------------------------------------------------+
#property strict
#include <Trade/Trade.mqh>
#include "Config.mqh"
#include "Helpers.mqh"

//+
// کلاس مدیریت معاملات
//+
class CTradeManager {
private:
   CTrade m_trade;
   string m_symbol;
   int m_magic;

   bool ValidateSignal(const TradeSignal &signal);
   double CalculatePositionSize(const TradeSignal &signal);
   bool CheckRiskLimits();

public:
   CTradeManager(const string symbol);
   ~CTradeManager();

   bool OpenTrade(const TradeSignal &signal, string &errorMsg);
   bool CloseTrade(const ulong ticket, const string reason = "");
   bool CloseAllTrades(const string direction = "");
   bool ModifySlTp(const ulong ticket, const double sl, const double tp);

   int GetOpenProfit();
   int GetDailyPnL();
};

//+
// سازنده
//+
CTradeManager::CTradeManager(const string symbol) {
   m_symbol = symbol;
   m_magic = (int)StringToInteger(MagicNumber);
   m_trade.SetExpertMagicNumber(m_magic);
   m_trade.SetDeviationInPoints(Slippage);
}

//+
// مخرب
//+
CTradeManager::~CTradeManager() {
}

//+
// اعتبارسنجی سیگنال
//+
bool CTradeManager::ValidateSignal(const TradeSignal &signal) {
   // بررسی امتیاز
   if(signal.totalScore < MinEntryScore) {
      LogMessage("امتیاز سیگنال کمتر از حد نصاب: " + IntegerToString(signal.totalScore), "WARNING");
      return false;
   }

   // بررسی ورود مجاز
   if(!signal.entryAllowed) {
      LogMessage("ورود مجاز نیست: " + signal.reason, "WARNING");
      return false;
   }

   return true;
}

//+
// محاسبه حجم پوزیشن
//+
double CTradeManager::CalculatePositionSize(const TradeSignal &signal) {
   // если лат ثابت تنظیم شده
   if(FixedLot > 0) {
      return NormalizeDouble(FixedLot, 2);
   }

   // محاسبه بر اساس ریسک
   double slPoints = MathAbs(signal.entryPrice - signal.stopLoss) /
      SymbolInfoDouble(m_symbol, SYMBOL_POINT);

   double lot = CalculateLotSize(m_symbol, RiskPercent, (int)slPoints);

   // اعمال محدودیت‌ها
   lot = MathMax(lot, MinLot);
   lot = MathMin(lot, MaxLot);

   return NormalizeDouble(lot, 2);
}

//+
// بررسی محدودیت‌های ریسک
//+
bool CTradeManager::CheckRiskLimits() {
   // بررسی تعداد معاملات روزانه
   if(CountTodayTrades() >= MaxDailyTrades) {
      LogMessage("حداکثر معاملات روزانه", "WARNING");
      return false;
   }

   // بررسی تعداد معاملات همزمان
   if(CountOpenTrades(m_symbol) >= MaxOpenTrades) {
      LogMessage("حداکثر معاملات همزمان", "WARNING");
      return false;
   }

   // بررسی اسپرد
   int currentSpread = (int)SymbolInfoInteger(m_symbol, SYMBOL_SPREAD);
   if(currentSpread > MaxSpread) {
      LogMessage("اسپرد بالا: " + IntegerToString(currentSpread), "WARNING");
      return false;
   }

   return true;
}

//+
// باز کردن معامله
//+
bool CTradeManager::OpenTrade(const TradeSignal &signal, string &errorMsg) {
   // اعتبارسنجی
   if(!ValidateSignal(signal)) {
      errorMsg = "اعتبارسنجی سیگنال ناموفق";
      return false;
   }

   // بررسی محدودیت‌ها
   if(!CheckRiskLimits()) {
      errorMsg = "محدودیت‌های ریسک نقض شده";
      return false;
   }

   // محاسبه حجم
   double volume = CalculatePositionSize(signal);

   // تعیین نوع سفارش
   ENUM_ORDER_TYPE orderType;
   double price;

   if(signal.direction == "buy") {
      orderType = ORDER_TYPE_BUY;
      price = SymbolInfoDouble(m_symbol, SYMBOL_ASK);
   } else if(signal.direction == "sell") {
      orderType = ORDER_TYPE_SELL;
      price = SymbolInfoDouble(m_symbol, SYMBOL_BID);
   } else {
      errorMsg = "جهت نامعتبر";
      return false;
   }

   // تنظیم حد ضرر و سود
   double sl = 0, tp = 0;

   if(signal.stopLoss > 0) {
      sl = signal.stopLoss;
   } else {
      sl = (signal.direction == "buy") ?
         price - PointsToPrice(m_symbol, DefaultSL) :
         price + PointsToPrice(m_symbol, DefaultSL);
   }

   if(signal.takeProfit > 0) {
      tp = signal.takeProfit;
   } else {
      tp = CalculateTPByRR(price, sl, orderType, 2.0);
   }

   // نرمال‌سازی قیمت‌ها
   double tickSize = SymbolInfoDouble(m_symbol, SYMBOL_TRADE_TICK_SIZE);
   int digits = (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS);

   price = NormalizeDouble(price, digits);
   sl = NormalizeDouble(sl, digits);
   tp = NormalizeDouble(tp, digits);
   volume = NormalizeDouble(volume, 2);

   // ثبت لاگ
   LogTrade("باز کردن معامله", m_symbol, orderType, volume, price, sl, tp, signal.reason);

   // ارسال سفارش
   if(orderType == ORDER_TYPE_BUY) {
      if(!m_trade.Buy(volume, m_symbol, price, sl, tp, signal.reason)) {
         errorMsg = "خطا در ارسال سفارش: " + IntegerToString(GetLastError());
         LogMessage(errorMsg, "ERROR");
         return false;
      }
   } else {
      if(!m_trade.Sell(volume, m_symbol, price, sl, tp, signal.reason)) {
         errorMsg = "خطا در ارسال سفارش: " + IntegerToString(GetLastError());
         LogMessage(errorMsg, "ERROR");
         return false;
      }
   }

   LogMessage("معامله با موفقیت باز شد", "INFO");
   return true;
}

//+
// بستن معامله
//+
bool CTradeManager::CloseTrade(const ulong ticket, const string reason) {
   if(!PositionSelectByTicket(ticket)) {
      LogMessage("پوزیشن یافت نشد: " + IntegerToString(ticket), "ERROR");
      return false;
   }

   ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
   double volume = PositionGetDouble(POSITION_VOLUME);

   LogMessage("بستن معامله: " + IntegerToString(ticket) + " | دلیل: " + reason, "TRADE");

   if(posType == POSITION_TYPE_BUY) {
      return m_trade.PositionClose(ticket);
   } else {
      return m_trade.PositionClose(ticket);
   }
}

//+
// بستن همه معاملات
//+
bool CTradeManager::CloseAllTrades(const string direction) {
   int closed = 0;
   int failed = 0;

   for(int i = PositionsTotal() - 1; i >= 0; i--) {
      ulong ticket = PositionGetTicket(i);

      if(!PositionSelectByTicket(ticket)) continue;

      if(PositionGetInteger(POSITION_MAGIC) != m_magic) continue;
      if(PositionGetString(POSITION_SYMBOL) != m_symbol) continue;

      // فیلتر جهت
      if(direction != "") {
         ENUM_POSITION_TYPE posType = (ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
         if(direction == "buy" && posType != POSITION_TYPE_BUY) continue;
         if(direction == "sell" && posType != POSITION_TYPE_SELL) continue;
      }

      if(CloseTrade(ticket, "بستن همه")) {
         closed++;
      } else {
         failed++;
      }
   }

   LogMessage(StringFormat("بسته شد: %d | ناموفق: %d", closed, failed), "TRADE");

   return failed == 0;
}

//+
// تغییر حد ضرر و سود
//+
bool CTradeManager::ModifySlTp(const ulong ticket, const double sl, const double tp) {
   if(!PositionSelectByTicket(ticket)) {
      return false;
   }

   int digits = (int)SymbolInfoInteger(m_symbol, SYMBOL_DIGITS);
   double normSl = NormalizeDouble(sl, digits);
   double normTp = NormalizeDouble(tp, digits);

   return m_trade.PositionModify(ticket, normSl, normTp);
}

//+
// دریافت سود معاملات باز
//+
int CTradeManager::GetOpenProfit() {
   double profit = 0;

   for(int i = PositionsTotal() - 1; i >= 0; i--) {
      ulong ticket = PositionGetTicket(i);

      if(!PositionSelectByTicket(ticket)) continue;

      if(PositionGetInteger(POSITION_MAGIC) == m_magic) {
         profit += PositionGetDouble(POSITION_PROFIT);
      }
   }

   return (int)(profit * 100);
}

//+
// دریافت سود/ضرر امروز
//+
int CTradeManager::GetDailyPnL() {
   double pnl = 0;
   datetime todayStart = StringToTime(TimeToString(TimeCurrent(), TIME_DATE));

   if(HistorySelect(todayStart, TimeCurrent())) {
      for(int i = HistoryDealsTotal() - 1; i >= 0; i--) {
         ulong ticket = HistoryDealGetTicket(i);

         if(HistoryDealGetInteger(ticket, DEAL_MAGIC) != m_magic) continue;

         double profit = HistoryDealGetDouble(ticket, DEAL_PROFIT);
         double swap = HistoryDealGetDouble(ticket, DEAL_SWAP);
         double commission = HistoryDealGetDouble(ticket, DEAL_COMMISSION);

         pnl += profit + swap + commission;
      }
   }

   return (int)(pnl * 100);
}
//+------------------------------------------------------------------+
