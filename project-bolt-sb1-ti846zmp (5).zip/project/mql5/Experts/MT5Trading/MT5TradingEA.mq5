//+------------------------------------------------------------------+
//|                                                MT5TradingEA.mq5   |
//|                                    MT5 Trading System             |
//|                                    اکسپرت ادوایزر اصلی            |
//+------------------------------------------------------------------+
#property copyright "MT5 Trading Team"
#property link      "https://mt5trading.com"
#property version   "1.00"
#property strict

#include <MT5Trading/Config.mqh>
#include <MT5Trading/Helpers.mqh>
#include <MT5Trading/SMCAnalyzer.mqh>
#include <MT5Trading/PAAnalyzer.mqh>
#include <MT5Trading/TradeManager.mqh>
#include <MT5Trading/DecisionEngine.mqh>

//+
// متغیرهای گلوبال
//+
CDecisionEngine *g_decisionEngine = NULL;
CTradeManager *g_tradeManager = NULL;

datetime g_lastAnalysisTime = 0;
int g_analysisInterval = 60;  // ثانیه

bool g_tradeEnabled = true;

//+
// تابع initialization
//+
int OnInit() {
   // بررسی نماد
   if(Symbol() == "") {
      Print("خطا: نماد تعیین نشده");
      return INIT_PARAMETERS_INCORRECT;
   }

   // ایجاد موتور تصمیم‌گیری
   g_decisionEngine = new CDecisionEngine(Symbol(), PERIOD_CURRENT);

   if(g_decisionEngine == NULL) {
      Print("خطا: ایجاد موتور تصمیم‌گیری ناموفق");
      return INIT_FAILED;
   }

   // ایجاد مدیر معاملات
   g_tradeManager = new CTradeManager(Symbol());

   if(g_tradeManager == NULL) {
      Print("خطا: ایجاد مدیر معاملات ناموفق");
      delete g_decisionEngine;
      return INIT_FAILED;
   }

   // لاگ راه‌اندازی
   LogMessage(StringFormat("اکسپرت راه‌اندازی شد | نماد: %s | تایم‌فریم: %s",
      Symbol(), EnumToString(Period())));

   return INIT_SUCCEEDED;
}

//+
// تابع deinitialization
//+
void OnDeinit(const int reason) {
   // حذف آبجکت‌ها
   if(g_decisionEngine) delete g_decisionEngine;
   if(g_tradeManager) delete g_tradeManager;

   LogMessage("اکسپرت متوقف شد | دلیل: " + IntegerToString(reason));
}

//+
// تابع اصلی تیک
//+
void OnTick() {
   // بررسی زمان تحلیل
   if(TimeCurrent() - g_lastAnalysisTime < g_analysisInterval) {
      return;
   }

   g_lastAnalysisTime = TimeCurrent();

   // بررسی اتصال
   if(!TerminalInfoInteger(TERMINAL_CONNECTED)) {
      LogMessage("عدم اتصال به سرور", "WARNING");
      return;
   }

   // بررسی معاملات باز
   CheckOpenPositions();

   // تحلیل و تصمیم‌گیری
   if(g_tradeEnabled && IsNewBar()) {
      AnalyzeAndTrade();
   }
}

//+
// بررسی کندل جدید
//+
bool IsNewBar() {
   static datetime lastBarTime = 0;

   datetime currentBarTime = iTime(Symbol(), PERIOD_CURRENT, 0);

   if(currentBarTime != lastBarTime) {
      lastBarTime = currentBarTime;
      return true;
   }

   return false;
}

//+
// تحلیل و معامله
//+
void AnalyzeAndTrade() {
   if(g_decisionEngine == NULL || g_tradeManager == NULL) {
      return;
   }

   // تحلیل
   TradeSignal signal;
   ZeroMemory(signal);

   if(!g_decisionEngine.Analyze(signal)) {
      LogMessage("تحلیل ناموفق", "WARNING");
      return;
   }

   // لاگ نتیجه تحلیل
   LogMessage(StringFormat("تحلیل | امتیاز: %d | جهت: %s | مجاز: %s | دلیل: %s",
      signal.totalScore,
      signal.direction,
      signal.entryAllowed ? "بله" : "خیر",
      signal.reason));

   // بررسی ورود
   if(signal.entryAllowed && signal.totalScore >= MinEntryScore) {
      ExecuteTrade(signal);
   }
}

//+
// اجرای معامله
//+
void ExecuteTrade(TradeSignal &signal) {
   if(g_tradeManager == NULL) return;

   string errorMsg;
   if(!g_tradeManager.OpenTrade(signal, errorMsg)) {
      LogMessage("خطا در باز کردن معامله: " + errorMsg, "ERROR");
      return;
   }

   // ارسال اعلان تلگرام
   if(EnableTelegram) {
      SendTelegramNotification(signal);
   }
}

//+
// بررسی پوزیشن‌های باز
//+
void CheckOpenPositions() {
   if(g_tradeManager == NULL) return;

   for(int i = PositionsTotal() - 1; i >= 0; i--) {
      ulong ticket = PositionGetTicket(i);

      if(!PositionSelectByTicket(ticket)) continue;

      // بررسی Magic Number
      if(PositionGetInteger(POSITION_MAGIC) != (int)StringToInteger(MagicNumber)) continue;

      // بررسی نماد
      if(PositionGetString(POSITION_SYMBOL) != Symbol()) continue;

      // مدیریت حد ضرر متحرک
      if(UseDynamicSLTP) {
         ManageTrailingStop(ticket);
      }

      // بررسی زمان معامله
      CheckTradeDuration(ticket);
   }
}

//+
// مدیریت حد ضرر متحرک
//+
void ManageTrailingStop(const ulong ticket) {
   double currentPrice = PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY ?
      SymbolInfoDouble(Symbol(), SYMBOL_BID) :
      SymbolInfoDouble(Symbol(), SYMBOL_ASK);

   double sl = PositionGetDouble(POSITION_SL);
   double openPrice = PositionGetDouble(POSITION_PRICE_OPEN);
   double tp = PositionGetDouble(POSITION_TP);

   double point = SymbolInfoDouble(Symbol(), SYMBOL_POINT);
   int digits = (int)SymbolInfoInteger(Symbol(), SYMBOL_DIGITS);

   // تریلینگ بعد از رسیدن به R:R 1:1
   double riskPoints = MathAbs(openPrice - sl) / point;

   if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) {
      double profitPoints = (currentPrice - openPrice) / point;

      if(profitPoints >= riskPoints) {
         double newSL = currentPrice - (riskPoints * 0.5 * point);
         newSL = NormalizeDouble(newSL, digits);

         if(newSL > sl + (10 * point)) {
            g_tradeManager.ModifySlTp(ticket, newSL, tp);
         }
      }
   } else {
      double profitPoints = (openPrice - currentPrice) / point;

      if(profitPoints >= riskPoints) {
         double newSL = currentPrice + (riskPoints * 0.5 * point);
         newSL = NormalizeDouble(newSL, digits);

         if(newSL < sl - (10 * point) || sl == 0) {
            g_tradeManager.ModifySlTp(ticket, newSL, tp);
         }
      }
   }
}

//+
// بررسی مدت معامله
//+
void CheckTradeDuration(const ulong ticket) {
   datetime openTime = (datetime)PositionGetInteger(POSITION_TIME);
   int duration = (int)(TimeCurrent() - openTime) / 3600;  // ساعت

   // بستن معاملات قدیمی (بیش از 24 ساعت)
   if(duration > 24) {
      LogMessage("معامله قدیمی: " + IntegerToString(ticket), "INFO");
      // می‌توان معامله را بست
      // g_tradeManager.CloseTrade(ticket, "مدت زیاد");
   }
}

//+
// ارسال اعلان تلگرام
//+
void SendTelegramNotification(TradeSignal &signal) {
   string message = StringFormat(
      "🔔 سیگنال جدید\n\n" +
      "📈 نماد: %s\n" +
      "🎯 جهت: %s\n" +
      "📊 امتیاز: %d/100\n\n" +
      "📍 ورود: %.5f\n" +
      "🛡 حد ضرر: %.5f\n" +
      "🎯 حد سود: %.5f\n\n" +
      "⏰ %s",
      signal.symbol,
      signal.direction == "buy" ? "خرید 🟢" : "فروش 🔴",
      signal.totalScore,
      signal.entryPrice,
      signal.stopLoss,
      signal.takeProfit,
      TimeToString(TimeCurrent(), TIME_DATE|TIME_MINUTES)
   );

   // ارسال به API برای تلگرام
   string body = StringFormat(
      "{\"message\":\"%s\",\"chat_id\":\"%s\"}",
      message,
      "-"  // Chat ID from config
   );

   SendApiRequest("/telegram/send", "POST", body);
}

//+
// دستورات دکمه‌ای (برای تست)
//+
void OnChartEvent(
   const int id,
   const long &lparam,
   const double &dparam,
   const string &sparam
) {
   // تابع خالی برای استفاده آینده
}
//+------------------------------------------------------------------+
