"""
هندلرهای معاملات

نویسنده: MT5 Trading Team
"""

from aiogram import Dispatcher, types, F
from aiogram.fsm.context import FSMContext
import httpx

from ..keyboards import get_trades_keyboard, get_confirm_keyboard
from ..utils import format_trade_list, format_trade_detail
from ....core.logger import get_logger

logger = get_logger("telegram.handlers.trades")


def register_trade_handlers(dp: Dispatcher):
    """ثبت هندلرهای معاملات"""

    @dp.message(F.text == "📈 معاملات من")
    async def menu_trades(message: types.Message):
        """نمایش منوی معاملات"""
        await message.answer(
            "📈 <b>مدیریت معاملات</b>\n\n"
            "گزینه مورد نظر را انتخاب کنید:",
            reply_markup=get_trades_keyboard(),
            parse_mode="HTML"
        )

    @dp.callback_query(F.data == "trades_open")
    async def show_open_trades(callback: types.CallbackQuery):
        """نمایش معاملات باز"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "http://localhost:8000/api/trades/open",
                    headers={"Authorization": f"Bearer {callback.from_user.id}"},
                    timeout=10.0
                )

            if response.status_code == 200:
                result = response.json()
                trades = result.get("data", {}).get("positions", [])

                if not trades:
                    await callback.message.edit_text(
                        "📭 <b>معادله باز</b>\n\n"
                        "هیچ معامله‌ای باز نیست.",
                        parse_mode="HTML"
                    )
                else:
                    text = format_trade_list(trades, "معاملات باز")
                    await callback.message.edit_text(
                        text,
                        parse_mode="HTML"
                    )
            else:
                await callback.message.edit_text(
                    "❌ خطا در دریافت معاملات",
                    parse_mode="HTML"
                )

        except Exception as e:
            logger.error(f"خطا در دریافت معاملات: {e}")
            await callback.message.edit_text(
                "❌ خطا در ارتباط با سرور",
                parse_mode="HTML"
            )

        await callback.answer()

    @dp.callback_query(F.data == "trades_history")
    async def show_trade_history(callback: types.CallbackQuery):
        """نمایش تاریخچه معاملات"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "http://localhost:8000/api/trades/",
                    params={"limit": 20},
                    timeout=10.0
                )

            if response.status_code == 200:
                result = response.json()
                trades = result.get("data", {}).get("trades", [])

                if not trades:
                    await callback.message.edit_text(
                        "📭 <b>تاریخچه معاملات</b>\n\n"
                        "هیچ معامله‌ای ثبت نشده.",
                        parse_mode="HTML"
                    )
                else:
                    text = format_trade_list(trades, "تاریخچه معاملات")
                    await callback.message.edit_text(
                        text,
                        parse_mode="HTML"
                    )
            else:
                await callback.message.edit_text(
                    "❌ خطا در دریافت تاریخچه",
                    parse_mode="HTML"
                )

        except Exception as e:
            logger.error(f"خطا در دریافت تاریخچه: {e}")
            await callback.message.edit_text(
                "❌ خطا در ارتباط با سرور",
                parse_mode="HTML"
            )

        await callback.answer()

    @dp.callback_query(F.data == "trades_close_all")
    async def confirm_close_all(callback: types.CallbackQuery):
        """تأیید بستن همه معاملات"""
        await callback.message.edit_text(
            "⚠️ <b>هشدار!</b>\n\n"
            "آیا مطمئن هستید که می‌خواهید\n"
            "همه معاملات باز را ببندید؟",
            reply_markup=get_confirm_keyboard("close_all"),
            parse_mode="HTML"
        )
        await callback.answer()

    @dp.callback_query(F.data == "confirm_close_all")
    async def execute_close_all(callback: types.CallbackQuery):
        """بستن همه معاملات"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    "http://localhost:8000/api/trades/close-all",
                    timeout=30.0
                )

            if response.status_code == 200:
                result = response.json()
                data = result.get("data", {})

                await callback.message.edit_text(
                    f"✅ <b>معاملات بسته شدند</b>\n\n"
                    f"تعداد: {data.get('closed_count', 0)}\n"
                    f"سود/ضرر: ${data.get('total_profit', 0):.2f}",
                    parse_mode="HTML"
                )
            else:
                await callback.message.edit_text(
                    "❌ خطا در بستن معاملات",
                    parse_mode="HTML"
                )

        except Exception as e:
            logger.error(f"خطا در بستن معاملات: {e}")
            await callback.message.edit_text(
                "❌ خطا در ارتباط با سرور",
                parse_mode="HTML"
            )

        await callback.answer()

    @dp.callback_query(F.data == "cancel_close_all")
    async def cancel_close_all(callback: types.CallbackQuery):
        """لغو بستن معاملات"""
        await callback.message.edit_text(
            "❌ عملیات لغو شد.",
            parse_mode="HTML"
        )
        await callback.answer()

    @dp.callback_query(F.data.startswith("trade_"))
    async def show_trade_detail(callback: types.CallbackQuery):
        """جزئیات معامله"""
        trade_id = callback.data.split("_")[1]

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"http://localhost:8000/api/trades/{trade_id}",
                    timeout=10.0
                )

            if response.status_code == 200:
                result = response.json()
                trade = result.get("data", {})

                text = format_trade_detail(trade)
                await callback.message.edit_text(
                    text,
                    parse_mode="HTML"
                )
            else:
                await callback.message.edit_text(
                    "❌ معامله یافت نشد",
                    parse_mode="HTML"
                )

        except Exception as e:
            logger.error(f"خطا در دریافت جزئیات: {e}")
            await callback.message.edit_text(
                "❌ خطا در ارتباط با سرور",
                parse_mode="HTML"
            )

        await callback.answer()
