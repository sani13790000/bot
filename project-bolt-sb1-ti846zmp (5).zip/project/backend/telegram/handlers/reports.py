"""
هندلرهای گزارش‌ها

نویسنده: MT5 Trading Team
"""

from aiogram import Dispatcher, types, F
import httpx

from ..keyboards import get_reports_keyboard
from ..utils import format_report_summary
from ....core.logger import get_logger

logger = get_logger("telegram.handlers.reports")


def register_report_handlers(dp: Dispatcher):
    """ثبت هندلرهای گزارش‌ها"""

    @dp.message(F.text == "📋 گزارش‌ها")
    async def menu_reports(message: types.Message):
        """نمایش منوی گزارش‌ها"""
        await message.answer(
            "📋 <b>گزارش‌ها</b>\n\n"
            "نوع گزارش را انتخاب کنید:",
            reply_markup=get_reports_keyboard(),
            parse_mode="HTML"
        )

    @dp.callback_query(F.data == "report_daily")
    async def show_daily_report(callback: types.CallbackQuery):
        """گزارش روزانه"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "http://localhost:8000/api/reports/daily",
                    timeout=10.0
                )

            if response.status_code == 200:
                result = response.json()
                data = result.get("data", {})
                summary = data.get("summary", {})

                total = summary.get("total_trades", 0)
                winning = summary.get("winning_trades", 0)
                losing = summary.get("losing_trades", 0)
                win_rate = summary.get("win_rate", 0)
                net_profit = summary.get("net_profit", 0)

                gross_profit = summary.get("gross_profit", 0)
                gross_loss = summary.get("gross_loss", 0)

                text = f"""
📅 <b>گزارش روزانه</b>
تاریخ: {data.get('date', '---')}</b>

📊 <b>خلاصه:</b>
• تعداد معاملات: {total}
• برنده: {winning} 🟢
• بازنده: {losing} 🔴
• وین ریت: {win_rate:.1f}%

💰 <b>مالی:</b>
• سود ناخالص: ${gross_profit:.2f}
• ضرر ناخالص: ${abs(gross_loss):.2f}
• سود/ضرر خالص: ${net_profit:.2f}

{'✅' if net_profit >= 0 else '📉'} <b>نتیجه:</b> {'سودده' if net_profit >= 0 else 'زیان‌ده'}
"""
                await callback.message.edit_text(text, parse_mode="HTML")
            else:
                await callback.message.edit_text(
                    "❌ خطا در دریافت گزارش",
                    parse_mode="HTML"
                )

        except Exception as e:
            logger.error(f"خطا در دریافت گزارش روزانه: {e}")
            await callback.message.edit_text(
                "❌ خطا در ارتباط با سرور",
                parse_mode="HTML"
            )

        await callback.answer()

    @dp.callback_query(F.data == "report_weekly")
    async def show_weekly_report(callback: types.CallbackQuery):
        """گزارش هفتگی"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "http://localhost:8000/api/reports/weekly",
                    timeout=10.0
                )

            if response.status_code == 200:
                result = response.json()
                data = result.get("data", {})
                summary = data.get("summary", {})
                breakdown = data.get("daily_breakdown", [])

                text = f"""
📆 <b>گزارش هفتگی</b>
از {data.get('week_start', '---')} تا {data.get('week_end', '---')}

📊 <b>خلاصه:</b>
• تعداد معاملات: {summary.get('total_trades', 0)}
• سود/ضرر کل: ${summary.get('total_profit', 0):.2f}
• وین ریت: {summary.get('win_rate', 0):.1f}%

📈 <b>تفکیک روزانه:</b>
"""
                for day in breakdown:
                    profit_emoji = "🟢" if day.get("profit", 0) >= 0 else "🔴"
                    text += f"\n{profit_emoji} {day.get('date', '---')}: {day.get('trades', 0)} معامله | ${day.get('profit', 0):.2f}"

                await callback.message.edit_text(text, parse_mode="HTML")
            else:
                await callback.message.edit_text(
                    "❌ خطا در دریافت گزارش",
                    parse_mode="HTML"
                )

        except Exception as e:
            logger.error(f"خطا در دریافت گزارش هفتگی: {e}")
            await callback.message.edit_text(
                "❌ خطا در ارتباط با سرور",
                parse_mode="HTML"
            )

        await callback.answer()

    @dp.callback_query(F.data == "report_monthly")
    async def show_monthly_report(callback: types.CallbackQuery):
        """گزارش ماهانه"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "http://localhost:8000/api/reports/monthly",
                    timeout=10.0
                )

            if response.status_code == 200:
                result = response.json()
                data = result.get("data", {})
                summary = data.get("summary", {})

                text = f"""
🗓 <b>گزارش ماهانه</b>
ماه: {data.get('month', '---')}

📊 <b>خلاصه:</b>
• تعداد معاملات: {summary.get('total_trades', 0)}
• برنده: {summary.get('winning_trades', 0)} 🟢
• بازنده: {summary.get('losing_trades', 0)} 🔴
• وین ریت: {summary.get('win_rate', 0):.1f}%

💰 <b>سود/ضرر خالص:</b> ${summary.get('net_profit', 0):.2f}
"""
                await callback.message.edit_text(text, parse_mode="HTML")
            else:
                await callback.message.edit_text(
                    "❌ خطا در دریافت گزارش",
                    parse_mode="HTML"
                )

        except Exception as e:
            logger.error(f"خطا در دریافت گزارش ماهانه: {e}")
            await callback.message.edit_text(
                "❌ خطا در ارتباط با سرور",
                parse_mode="HTML"
            )

        await callback.answer()

    @dp.callback_query(F.data == "report_performance")
    async def show_performance(callback: types.CallbackQuery):
        """عملکرد کلی"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    "http://localhost:8000/api/reports/performance",
                    params={"period": "all"},
                    timeout=10.0
                )

            if response.status_code == 200:
                result = response.json()
                data = result.get("data", {})
                metrics = data.get("metrics", {})

                profit_factor = metrics.get("profit_factor", 0)
                pf_status = "عالی" if profit_factor > 2 else "خوب" if profit_factor > 1.5 else "نیاز به بهبود"

                text = f"""
📊 <b>عملکرد کلی</b>

📈 <b>معیارهای عملکرد:</b>
• تعداد کل معاملات: {metrics.get('total_trades', 0)}
• برنده: {metrics.get('winning_trades', 0)} 🟢
• بازنده: {metrics.get('losing_trades', 0)} 🔴

🎯 <b>نرخ موفقیت:</b>
• وین ریت: {metrics.get('win_rate', 0):.1f}%
• فاکتور سود: {profit_factor:.2f} ({pf_status})

💰 <b>سود و ضرر:</b>
• سود ناخالص: ${metrics.get('gross_profit', 0):.2f}
• ضرر ناخالص: ${metrics.get('gross_loss', 0):.2f}
• سود خالص: ${metrics.get('net_profit', 0):.2f}
• میانگین هر معامله: ${metrics.get('avg_trade', 0):.2f}
"""
                await callback.message.edit_text(text, parse_mode="HTML")
            else:
                await callback.message.edit_text(
                    "❌ خطا در دریافت عملکرد",
                    parse_mode="HTML"
                )

        except Exception as e:
            logger.error(f"خطا در دریافت عملکرد: {e}")
            await callback.message.edit_text(
                "❌ خطا در ارتباط با سرور",
                parse_mode="HTML"
            )

        await callback.answer()
