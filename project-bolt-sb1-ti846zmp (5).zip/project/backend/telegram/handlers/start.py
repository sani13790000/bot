"""
هندلرهای شروع و منوی اصلی

نویسنده: MT5 Trading Team
"""

from aiogram import Dispatcher, types, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext

from ..keyboards import get_main_keyboard
from ..utils import format_welcome_message
from ....core.logger import get_logger

logger = get_logger("telegram.handlers.start")


def register_start_handlers(dp: Dispatcher):
    """ثبت هندلرهای شروع"""

    @dp.message(CommandStart())
    async def cmd_start(message: types.Message, state: FSMContext):
        """
        هندلر دستور /start
        """
        await state.clear()

        user_id = message.from_user.id
        username = message.from_user.username or "کاربر"

        logger.info(f"کاربر جدید: {user_id} (@{username})")

        await message.answer(
            format_welcome_message(username),
            reply_markup=get_main_keyboard(),
            parse_mode="HTML"
        )

    @dp.message(Command("help"))
    async def cmd_help(message: types.Message):
        """
        هندلر دستور /help
        """
        help_text = """
📖 <b>راهنمای استفاده از ربات</b>

<b>📊 تحلیل بازار:</b>
تحلیل SMC و Price Action نمادها با امتیاز ورود

<b>📈 معاملات:</b>
مشاهده معاملات باز و بسته شده

<b>🔔 سیگنال‌ها:</b>
سیگنال‌های خرید و فروش با حد ضرر/سود

<b>⚙️ تنظیمات:</b>
پیکربندی ربات و تنظیمات شخصی

<b>📋 گزارش‌ها:</b>
گزارش روزانه، هفتگی و ماهانه

<b>دستورات:</b>
/start - شروع
/help - راهنما
/status - وضعیت اکانت
/balance - موجودی

<b>⚠️ توجه:</b>
حداقل امتیاز ورود: 65 از 100
        """
        await message.answer(help_text, parse_mode="HTML")

    @dp.message(Command("status"))
    async def cmd_status(message: types.Message):
        """
        هندلر دستور /status
        """
        # این باید از API دریافت شود
        status_text = """
📊 <b>وضعیت اکانت</b>

✅ متصل به MT5
💰 موجودی: $10,000.00
📈 معاملات باز: 0
🔔 سیگنال‌های فعال: 0
        """
        await message.answer(status_text, parse_mode="HTML")

    @dp.message(Command("balance"))
    async def cmd_balance(message: types.Message):
        """
        هندلر دستور /balance
        """
        balance_text = """
💰 <b>اطلاعات حساب</b>

💵 موجودی: $10,000.00
📊 اکوئیتی: $10,100.00
📈 سود/ضرر روز: $100.00
📉 مارجین استفاده: $500.00
🔐 مارجین آزاد: $9,500.00
        """
        await message.answer(balance_text, parse_mode="HTML")

    @dp.message(F.text == "❓ راهنما")
    async def menu_help(message: types.Message):
        """هندلر دکمه راهنما"""
        await cmd_help(message)

    @dp.callback_query(F.data == "back_main")
    async def back_to_main(callback: types.CallbackQuery, state: FSMContext):
        """بازگشت به منوی اصلی"""
        await state.clear()
        await callback.message.edit_text(
            "🏠 <b>منوی اصلی</b>",
            parse_mode="HTML"
        )
        await callback.message.answer(
            "چه کاری می‌خواهید انجام دهید؟",
            reply_markup=get_main_keyboard()
        )
        await callback.answer()
