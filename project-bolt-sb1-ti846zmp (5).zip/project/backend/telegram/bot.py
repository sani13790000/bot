"""
ربات تلگرام MT5 Trading

نویسنده: MT5 Trading Team
"""

import asyncio
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.exceptions import TelegramAPIError

from .handlers import setup_handlers
from .keyboards import get_main_keyboard
from ..core.config import settings
from ..core.logger import get_logger

logger = get_logger("telegram.bot")


class TelegramBot:
    """
    کلاس اصلی ربات تلگرام
    """

    def __init__(self):
        self.bot: Bot = None
        self.dp: Dispatcher = None
        self._running = False

    async def initialize(self):
        """
        راه‌اندازی اولیه ربات
        """
        if not settings.TELEGRAM_BOT_TOKEN:
            logger.warning("توکن ربات تلگرام تنظیم نشده است")
            return

        self.bot = Bot(token=settings.TELEGRAM_BOT_TOKEN)
        self.dp = Dispatcher()

        # ثبت هندلرها
        setup_handlers(self.dp)

        # ثبت هندلر خطا
        self.dp.error.register(self._error_handler)

        logger.info("ربات تلگرام راه‌اندازی شد")

    async def start(self):
        """
        شروع ربات
        """
        if not self.bot:
            await self.initialize()

        if not self.bot:
            logger.error("نمی‌توان ربات را بدون توکن راه‌اندازی کرد")
            return

        self._running = True

        try:
            logger.info("شروع polling ربات تلگرام")
            await self.dp.start_polling(self.bot, allowed_updates=["message", "callback_query"])
        except Exception as e:
            logger.error(f"خطا در اجرای ربات: {e}")
            self._running = False

    async def stop(self):
        """
        توقف ربات
        """
        if self.bot:
            await self.bot.session.close()
        if self.dp:
            await self.dp.stop_polling()
        self._running = False
        logger.info("ربات تلگرام متوقف شد")

    async def _error_handler(self, update, exception):
        """
        هندلر خطاهای کلی
        """
        logger.error(f"خطا در پردازش آپدیت: {exception}")
        return True

    async def send_message(
        self,
        chat_id: int,
        text: str,
        parse_mode: str = "HTML",
        **kwargs
    ):
        """
        ارسال پیام
        """
        if not self.bot:
            logger.error("ربات راه‌اندازی نشده است")
            return None

        try:
            return await self.bot.send_message(
                chat_id=chat_id,
                text=text,
                parse_mode=parse_mode,
                **kwargs
            )
        except TelegramAPIError as e:
            logger.error(f"خطا در ارسال پیام: {e}")
            return None

    async def send_signal_alert(self, chat_id: int, signal_data: dict):
        """
        ارسال اعلان سیگنال جدید
        """
        from .utils import format_signal_card
        from .keyboards import get_signal_action_keyboard

        text = format_signal_card(signal_data)
        keyboard = get_signal_action_keyboard(signal_data.get("id"))

        return await self.send_message(
            chat_id=chat_id,
            text=text,
            reply_markup=keyboard
        )

    async def send_trade_alert(self, chat_id: int, trade_data: dict):
        """
        ارسال اعلان معامله جدید
        """
        from .utils import format_trade_detail

        text = format_trade_detail(trade_data)

        return await self.send_message(
            chat_id=chat_id,
            text=text
        )

    async def send_daily_report(self, chat_id: int, report_data: dict):
        """
        ارسال گزارش روزانه
        """
        from .utils import format_report_summary

        text = format_report_summary(report_data)

        return await self.send_message(
            chat_id=chat_id,
            text=text
        )

    @property
    def is_running(self) -> bool:
        """بررسی وضعیت اجرای ربات"""
        return self._running


# نمونه گلوبال
telegram_bot = TelegramBot()


async def start_telegram_bot():
    """
    تابع شروع ربات (برای استفاده در main)
    """
    await telegram_bot.start()


async def stop_telegram_bot():
    """
    تابع توقف ربات
    """
    await telegram_bot.stop()
